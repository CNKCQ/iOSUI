//
//  Food.swift
//  Generic
//
//  Created by KingCQ on 2016/12/5.
//  Copyright © 2016年 KingCQ. All rights reserved.
//

import Foundation

class Food: NSObject {
    var eatable = true
    var nick = "只是个测试的"
    
}
